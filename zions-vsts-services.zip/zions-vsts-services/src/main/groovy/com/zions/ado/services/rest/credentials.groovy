package com.zions.ado.services.rest
// Visit https://darksky.net/dev/ to sign up for an API key then insert it below
apiKey='76a5a9fa26363c22922c0366c389939e'

database.user = 'root'
database.password = 'p@ssw0rd'
